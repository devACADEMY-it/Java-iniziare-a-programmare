public class EsercizioCondizionali {

	public static void main(String[] args) {
		
		float importo=5000;
		int aliquota = 0;
		
		if (importo>=10000)
			aliquota=40;
		else if (importo>=5000)
			aliquota=30;
		else
			aliquota=15;
		
		System.out.println("Aliquota applicata = "+aliquota+"%");
		
		float tasse=importo*aliquota/100;
		System.out.println("Tasse da pagare = "+tasse+" euro");
		
	}

}
