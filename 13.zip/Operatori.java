
public class Operatori {

	public static void main(String[] args) {
		// mesi = 12
		// ricavo mensile = 1200
		// spese = 1600
		
		// dati in input (in ingresso) del problema
		int mesi = 12;
		int ricavo_mensile = 1800;
		int spese = 1600;
		
		// calcolare il ricavo totale annuo
		int ricavoTotaleAnnuo=mesi*ricavo_mensile;
		System.out.println("Ricavo totale annuo = "+ricavoTotaleAnnuo);
		
		// RISULTATO FINALE: guadagno netto a livello annuo
		int guadagno_netto_annuo=ricavoTotaleAnnuo-spese;
		System.out.println("Guadagno netto annuo = "+guadagno_netto_annuo);
		
		
	}

}