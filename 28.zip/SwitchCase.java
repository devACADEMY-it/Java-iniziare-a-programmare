public class SwitchCase {

	public static void main(String[] args) {
		
		int posizioneGara=15;
		
		switch(posizioneGara) {
		    case 1:
		    	System.out.println("Medaglia d'oro");
		    	break;
		    case 2:
		    	System.out.println("Medaglia d'argento");
		    	break;
		    case 3:
		    	System.out.println("Medaglia di bronzo");
		    	break;
		    default:
		    	System.out.println("Fuori dal podio");
		}
		System.out.println("FINE PROGRAMMA");
	}

}
