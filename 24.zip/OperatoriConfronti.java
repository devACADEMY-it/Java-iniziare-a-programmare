public class OperatoriConfronti {

	public static void main(String[] args) {
		
		float fatturato=8000;
		float tasse_pagate=3500;
		
		float perc_tasse=tasse_pagate/fatturato;
		
		System.out.println("Percentuale tasse? "+perc_tasse);
		System.out.println("Supera il 30 per cento? "+(perc_tasse>0.3));
		
		// 0.4375 => 43.75%
		System.out.println("Percentuale tasse: "+(perc_tasse*100)+"%");
	}

}
