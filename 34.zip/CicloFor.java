
public class CicloFor {

	public static void main(String[] args) {
		for (int contatore=1; contatore<=10; contatore++) {
			System.out.println("Iterazione n."+contatore);
		}
	}

}
