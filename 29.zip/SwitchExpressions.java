public class SwitchExpressions {

	public static void main(String[] args) {
		
		int posizioneGara=5;
		
		/*
		int premio=0;
		switch(posizioneGara) {
		
		    case 1,2,3 -> premio=100;
		    case 4,5,6 -> premio=50;
		    default -> premio=10;
		}*/
		
		int premio = switch(posizioneGara) {
		
	    case 1,2,3 -> {
	    	System.out.println("Primi tre!");
	    	yield 100;
	    }
	    case 4,5,6 -> {
	    	System.out.println("Secondi tre!");
	    	yield 50;
	    }
	    default -> {
	    	System.out.println("Dal settimo in poi!");
	    	yield 10;
	    }
	};
		
		System.out.println("Hai vinto "+premio+" buoni");
	}

}
