public class OperatoriLogica {

	public static void main(String[] args) {
		
		int eta=10;
		
		boolean risultato = (eta>=18) && (eta<65);
		System.out.println("Tra i 18 e i 65 anni (esclusi)? "+risultato);
		
		risultato = (eta<18) || (eta>=65);
		System.out.println("Minorenne o almeno 65 anni? "+risultato);
		
		System.out.println("Contrario di prima? "+ !risultato);
		
		boolean menu_con_bevanda = false;
		boolean menu_con_dolce = true;
		
		System.out.println("Menu accettabile? "+ (menu_con_bevanda ^ menu_con_dolce));
		
		
	}

}
