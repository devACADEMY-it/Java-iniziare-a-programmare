
public class StampaValori {

	public static void main(String[] args) {
		int[] valori=new int[10];
		valori[0]=11;
		valori[1]=3;
		valori[2]=45;
		valori[3]=31;
		valori[4]=55;
		
		for (int i=0; i<valori.length; i++)
			System.out.println("In posizione "+i+": "+valori[i]);
		
		System.out.println();
				
		int indice=0;
		while(indice<valori.length) {
			System.out.println("In posizione "+indice+": "+valori[indice]);
			indice++;
		}
		
	}

}
