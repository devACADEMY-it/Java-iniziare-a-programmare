public class OperatoriConTasse {

	public static void main(String[] args) {
		// mesi = 12
		// ricavo mensile = 1200
		// spese = 1600
		
		// dati in input (in ingresso) del problema
		int mesi = 12;
		int ricavo_mensile = 1800;
		int spese = 1600;
		float percentuale_ricavo_netto=0.75f;
		
		// calcolare il ricavo totale annuo
		int ricavoTotaleAnnuo=mesi*ricavo_mensile;
		float ricavo_totale_annuo_tassato=ricavoTotaleAnnuo*percentuale_ricavo_netto;
		System.out.println("Ricavo totale annuo = "+ricavoTotaleAnnuo);
		System.out.println("Ricavo totale annuo TASSATO = "+ricavo_totale_annuo_tassato);
		
		// RISULTATO FINALE: guadagno netto a livello annuo
		float guadagno_netto_annuo=ricavo_totale_annuo_tassato-spese;
		System.out.println("Guadagno netto annuo = "+guadagno_netto_annuo);
		
		
	}

}
