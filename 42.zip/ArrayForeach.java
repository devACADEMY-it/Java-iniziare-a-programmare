
public class ArrayForeach {

	public static void main(String[] args) {
		int[] valori= {11, 2, 34, 100, 18, 21,33, 6}; // new int[8]
		
		System.out.println("Dimensione dell'array? "+valori.length);
		
		for(int v: valori)
			System.out.println("--> "+v);
		
	}

}
