
public class OperazioniRipetute {

	public static void main(String[] args) {
		int contatore=0;
		while (contatore<6) {
		  System.out.println("Un saluto a tutti!");
		  contatore++;
		}
		System.out.println("FINE DEL PROGRAMMA");
	}

}
