
public class OperazioniRipetute {

	public static void main(String[] args) {
		int contatore=10;
		while (contatore>0) 
		  System.out.println("Iterazione n. "+contatore--);
		System.out.println("FINE DEL PROGRAMMA");
	}

}
