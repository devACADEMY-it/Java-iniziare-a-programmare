public class OperatoriBinari {

	public static void main(String[] args) {
		
		int numero = 56;
		
		int altro_numero = 0b00111000;
		
		//System.out.println("Somma = "+ (numero+altro_numero));
		
		// 56 = 00111000
		// 14 = 00001110
		System.out.println("Shift = "+ (numero>>2));
		
		// 56  = 00111000
		// 224 = 11100000
		System.out.println("Shift = "+ (numero<<2));
		
		// 56 = 00111000
		// 40 = 00101000
		numero&=40;
		System.out.println("Dopo AND = "+ numero);
		
		// ora numero vale 40 
		numero|=5;
		// 40 = 00101000
		//  5 = 00000101
		// 45 = 00101101
		System.out.println("Dopo OR = "+ numero);
		
	}

}
