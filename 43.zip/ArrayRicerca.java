
public class ArrayRicerca {

	public static void main(String[] args) {
		int da_cercare=34;
		int posizione_trovato=-1;
		int[] valori= {5,7,9,81,34,56};
		
		for(int i=0; i<valori.length; i++)
		{
			if (valori[i]==da_cercare) {
				posizione_trovato=i;
				break;
			}
		}
		
		if (posizione_trovato==-1)
			System.out.println("Valore non trovato");
		else
			System.out.println("Valore trovato in posizione "+posizione_trovato);
		
	}

}
