public class Conversione {

	public static void main(String[] args) {
		
		short numero_short=600;
		int intero=numero_short;
		
		System.out.println("Numero: "+intero);
		
		byte numero_byte=(byte) intero;
		System.out.println("Numero su byte: "+numero_byte);
		
		float virgola = (float) 45.6;
		System.out.println("Numero con virgola: "+virgola);
	}

}
