
public class OperatoriConfronto {

	public static void main(String[] args) {
		
		// uguale
		boolean risultato= 5 == 6;
		System.out.println("Sono uguali 5 e 6? "+risultato);
		
		// maggiore
		risultato= 5 > 6;
		System.out.println("5 maggiore di 6? "+risultato);
		
		// minore
		risultato= 5 < 6;
		System.out.println("5 minore di 6? "+risultato);
		
		// diversi
		risultato= 5 != 6;
		System.out.println("Sono diversi 5 e 6? "+risultato);
		
		// maggiore o uguale
		risultato= 5 >= 6;
		System.out.println("5 maggiore o uguale di 6? "+risultato);
		
		// minore o uguale
		risultato= 5 <= 6;
		System.out.println("5 minore o uguale di 6? "+risultato);
		
	}

}
