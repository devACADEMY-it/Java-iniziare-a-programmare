
public class CicloFor {

	public static void main(String[] args) {
		for (int contatore=10; contatore>=1; ) {
			System.out.println("Iterazione n."+contatore);
			contatore-=2;
		}
		System.out.println("FINE DEL PROGRAMMA");
	}

}
