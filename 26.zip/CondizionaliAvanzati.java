public class CondizionaliAvanzati {

	public static void main(String[] args) {
		
		int numeroInsufficienze=2;
		
		if (numeroInsufficienze>=3)
		{
			System.out.println("Studente bocciato");
		}
		else if (numeroInsufficienze>0)
			System.out.println("Studente promosso con riserva");
		else
			System.out.println("Studente promosso");
		
		System.out.println("FINE PROGRAMMA");
		
	}

}
