
public class SequenzeDiValori {

	public static void main(String[] args) {
		int[] valori=new int[10];
		valori[0]=11;
		valori[1]=3;
		valori[2]=45;
		valori[3]=31;
		
		System.out.println("In posizione 1: "+valori[1]);
		System.out.println("In posizione 3: "+valori[3]);
	}

}
