
public class ArrayMultipli {

	public static void main(String[] args) {
		int[][] matrice= {{1,2,3},{4,5,6},{7,8,9}};
		System.out.println("Valore in posizione (2,0): "+matrice[2][0]);
		
		System.out.println();
		
		for (int riga=0; riga<matrice.length; riga++)
			for (int colonna=0; colonna<matrice[riga].length; colonna++)
				System.out.println("Valore in posizione ("+riga+","+colonna+"): "
			                       +matrice[riga][colonna]);
		
		System.out.println();
		
		for (int riga=0; riga<matrice.length; riga++) {
			for (int colonna=0; colonna<matrice[riga].length; colonna++)
				System.out.print(matrice[riga][colonna]+" ");
			System.out.println();
		}
		
	}

}
