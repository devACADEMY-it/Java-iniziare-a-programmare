
public class OperazioniInterrotte {

	public static void main(String[] args) {
		int contatore=1;
		while (contatore<=10) {
		  System.out.println("Iterazione n."+contatore);
		  if (contatore==7)
		       break;
		  contatore++;
		}
		System.out.println("FINE DEL PROGRAMMA");
	}

}
