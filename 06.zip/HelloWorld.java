
public class HelloWorld {

	public static void main(String[] args) {
		// commento su una sola linea
		
		/*
		 * commenti
		 * su 
		 * più 
		 * righe
		 * 
		 * Elenco:
		 * - prima cosa da fare
		 * - seconda cosa da fare
		 * - etc.
		 * */
		System.out.println("Ciao mondo!"); 
		System.out.println("Ciao mondo!");
		System.out.println("Ciao mondo!");
	}
}
