public class Variabili {

	public static void main(String[] args) {
		int risultato=12-5*3;
		String saluto="Ciao mondo!";
		System.out.println(risultato);
		System.out.println(saluto);
	}

}