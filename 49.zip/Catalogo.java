
public class Catalogo {

	public static void main(String[] args) {
		
		String[] prodotti= {"Robot X", "Astuccio Y", "Zaino Z"};
		int[] prezzi={80, 25, 70};
		
		int sconto=10;
		
		String[] catalogo=new String[prodotti.length];
		for (int i=0; i<catalogo.length; i++) {
			if (prezzi[i]>=50)
				catalogo[i]=prodotti[i]+" (SCONTATO!!) a "+(prezzi[i]*(100-sconto)/100)+" euro";
			else
				catalogo[i]=prodotti[i]+" a "+prezzi[i]+" euro";
		}
		
		for (String voce: catalogo)
			System.out.println(voce);
		
			
	}

}
