
public class ArrayTabelline {

	public static void main(String[] args) {
		int tabellina_del=8;
		int[] tabellina=new int[10];
		
		for(int i=0; i<tabellina.length; i++)
			tabellina[i]=tabellina_del*(i+1);
		
		for (int valore: tabellina)
			System.out.println(valore);
		
	}

}
