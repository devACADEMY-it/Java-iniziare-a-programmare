public class Condizionali {

	public static void main(String[] args) {
		
		int eta=98;
		
		if (eta>=18) {
			System.out.println("Utente di anni "+eta);
			System.out.println("Utente maggiorenne");
		}
		else {
			System.out.println("Utente minorenne");
			System.out.println("Troppo giovane!");
		}
		
		
	}

}
