
public class Tabelline {

	public static void main(String[] args) {
		int tabellina_del=5;
		
		System.out.println("Tabellina del "+tabellina_del+" (con ciclo FOR)");
		for (int contatore=1; contatore<=10; contatore++)
			System.out.println(contatore+" X "+tabellina_del+" = "+(tabellina_del*contatore));
		
		System.out.println("\nTabellina del "+tabellina_del+" (con ciclo WHILE)");
		int contatore=1;
		while(contatore<=10) {
			System.out.println(contatore+" X "+tabellina_del+" = "+(tabellina_del*contatore));
			contatore++;
		}
	}

}
