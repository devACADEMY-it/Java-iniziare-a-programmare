
public class IterazioniSaltate {

	public static void main(String[] args) {
		for(int contatore=1; contatore<=10; contatore++){
			if (contatore%2==0) {
				System.out.println("*** Salto questa iterazione ("+contatore+")");
				continue;
			}
			System.out.println("Iterazione n."+contatore);
		}
	}

}
