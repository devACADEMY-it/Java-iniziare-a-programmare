
public class ArrayOperazioni {

	public static void main(String[] args) {
		int a[]= {3,4,5,6,7};
		int b[]= {5,6,7,3,4};
		
		int somma[]=new int[a.length];
		
		for (int i=0; i<somma.length; i++)
			somma[i]=a[i]+b[i];
					
		for (int v: somma)
			System.out.println(v);
		
		
	}

}
