public class Ternario {

	public static void main(String[] args) {
		
		int eta=5;
		
		/*if (eta>=18)
			System.out.println("Utente maggiorenne");
		else
			System.out.println("Utente minorenne");*/
		
		String fascia_eta = eta>=18?"maggiorenne":"minorenne";
		System.out.println("Utente "+fascia_eta);
		
		// eta>=18 ? "maggiorenne":"minorenne"
		// CONDIZIONE ? SE_VERO : SE_FALSO
		
	}

}
